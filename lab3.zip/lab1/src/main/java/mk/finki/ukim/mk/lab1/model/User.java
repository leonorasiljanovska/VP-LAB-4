package mk.finki.ukim.mk.lab1.model;

import jakarta.persistence.*;
import jakarta.transaction.Transactional;
import lombok.Getter;

import java.util.ArrayList;
import java.util.List;

@Getter
@Entity
@Table(name = "app_user")
public class User {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(nullable = false, unique = true)
    private String email;

    private String name;
    private String address;
    private String password;

//    @OneToMany(mappedBy = "user", cascade = CascadeType.ALL, fetch = FetchType.LAZY)
//    private EventBooking eventBooking;

    public User() {

    }

    public void setPassword(String password) {
        this.password = password;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public void setName(String name) {
        this.name = name;
    }

    public void setAddress(String address) {
        this.address = address;
    }

//    @Transactional
//    public void addBooking(EventBooking booking) {
//        bookings.add(booking);
//        booking.setUser(this);  // Ensure the bidirectional relationship is maintained
//    }
}
