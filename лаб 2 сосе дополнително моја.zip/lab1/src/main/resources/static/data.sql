INSERT INTO location (name) VALUES ('Location 1');
INSERT INTO location (name) VALUES ('Location 2');
INSERT INTO location (name) VALUES ('Location 3');
