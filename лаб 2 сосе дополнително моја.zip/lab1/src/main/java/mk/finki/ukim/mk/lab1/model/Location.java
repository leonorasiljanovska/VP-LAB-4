package mk.finki.ukim.mk.lab1.model;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.Getter;

@Data
@Entity
public class Location {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    private String name;
    private String address;
    private String capacity;
    private String description;

    public Location(String Name,String Address, String Capacity, String Description)
    {
        name=Name;
        address=Address;
        capacity=Capacity;
        description=Description;
    }

    public Location() {

    }
}
