package mk.finki.ukim.mk.lab1.service;


import mk.finki.ukim.mk.lab1.model.Event;

import java.util.List;
import java.util.Optional;

public interface EventService {
    List<Event> listAll();
    List<Event> searchEvents(String text);
    Optional<Event> findById(Long id);
    void saveEvent(String name, String description, Integer popularityScore, Long locationId);
    void updateEvent(Long eventId, String name, String description, Integer popularityScore, Long locationId);
    void deleteEvent(Long eventId);
}